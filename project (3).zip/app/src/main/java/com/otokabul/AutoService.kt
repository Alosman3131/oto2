package com.otokabul

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import kotlin.math.abs

class AutoService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var pending = false
    private var lastClick = 0L
    private var lastScan = 0L
    private var overlay: TextView? = null
    private var chip: TextView? = null
    private var onHome = false
    private var homePkgs: Set<String> = setOf("com.miui.home")
    private val priceRe = Regex("₺\\s*(\\d{1,5})")
    private val priceRe2 = Regex("(\\d{1,5})\\s*₺")
    private val legRe = Regex("(\\d+)\\s*dk[^\\d]{0,5}([\\d.,]+)\\s*(km|m)\\b")
    private val hideChip = Runnable { removeChip() }
    private val syncLoop = object : Runnable {
        override fun run() {
            License.sync(this@AutoService)
            handler.postDelayed(this, 1800000L)
        }
    }

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post { refreshOverlay() }
    }

    private class State {
        var btn: AccessibilityNodeInfo? = null
        var sawEarn = false
        var price: Int? = null
        var anyPrice: Int? = null
        val legs = ArrayList<Leg>()
    }

    private class Offer(val price: Int, val btn: AccessibilityNodeInfo, val pick: Leg?, val trip: Leg?)

    override fun onServiceConnected() {
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homePkgs = packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet() + "com.miui.home"
        } catch (_: Exception) {
        }
        onHome = homePkgs.contains(rootInActiveWindow?.packageName?.toString() ?: "")
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        refreshOverlay()
        handler.post(syncLoop)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(syncLoop)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        removeOverlay()
        removeChip()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString()
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != null &&
            pkg != packageName && pkg != "com.android.systemui"
        ) {
            val h = homePkgs.contains(pkg)
            if (h != onHome) {
                onHome = h
                updateVis()
            }
        }
        if (!Prefs.active(this) || pending || !License.valid(this)) return
        val now = SystemClock.uptimeMillis()
        if (now - lastClick < 4000 || now - lastScan < 100) return
        lastScan = now
        val o = scan() ?: return
        if (o.price < Prefs.minPrice(this)) return
        pending = true
        handler.postDelayed({
            try {
                if (Prefs.active(this)) {
                    val o2 = scan()
                    if (o2 != null && o2.price >= Prefs.minPrice(this)) {
                        click(o2.btn)
                        Prefs.addJob(this, o2.price, o2.pick, o2.trip)
                        lastClick = SystemClock.uptimeMillis()
                        showChip(o2)
                    }
                }
            } finally {
                pending = false
            }
        }, Prefs.delay(this))
    }

    private fun scan(): Offer? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        try {
            windows.forEach { w -> w.root?.let { roots.add(it) } }
        } catch (_: Exception) {
        }
        rootInActiveWindow?.let { roots.add(it) }
        for (r in roots) {
            val s = State()
            walk(r, s)
            val p = s.price ?: s.anyPrice
            if (s.btn != null && s.sawEarn && p != null) {
                val pick = if (s.legs.size >= 2) s.legs[0] else null
                val trip = if (s.legs.size >= 2) s.legs[1] else s.legs.firstOrNull()
                return Offer(p, s.btn!!, pick, trip)
            }
        }
        return null
    }

    private fun walk(n: AccessibilityNodeInfo?, s: State) {
        if (n == null) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty()) {
            if (t.equals("Kabul et", true) && s.btn == null) s.btn = n
            if (t.contains("Toplam kazanç", true)) s.sawEarn = true
            val m = priceRe.find(t) ?: priceRe2.find(t)
            if (m != null) {
                val v = m.groupValues[1].toInt()
                if (s.anyPrice == null) s.anyPrice = v
                if (s.sawEarn && s.price == null) s.price = v
            }
            legRe.findAll(t).forEach { s.legs.add(Leg(it.groupValues[1].toInt(), it.groupValues[2] + " " + it.groupValues[3])) }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), s)
    }

    private fun click(btn: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = btn
        while (n != null && !n.isClickable) n = n.parent
        val ok = n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        if (!ok) {
            val r = Rect()
            btn.getBoundsInScreen(r)
            val p = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null
            )
        }
    }

    private fun updateVis() {
        val v = if (onHome) View.GONE else View.VISIBLE
        overlay?.visibility = v
        chip?.visibility = v
    }

    private fun showChip(o: Offer) {
        val t = o.trip ?: return
        var s = "Yolculuk: ${t.min} dk · ${t.dist}"
        o.pick?.let { s += "\nYolcuya: ${it.min} dk · ${it.dist}" }
        handler.removeCallbacks(hideChip)
        removeChip()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pad = (12 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = s
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            background = GradientDrawable().apply { setColor(Color.argb(230, 17, 24, 39)); cornerRadius = 40f }
            visibility = if (onHome) View.GONE else View.VISIBLE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 120 }
        try {
            wm.addView(tv, lp)
            chip = tv
            handler.postDelayed(hideChip, 3000L)
        } catch (_: Exception) {
        }
    }

    private fun removeChip() {
        chip?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        chip = null
    }

    private fun refreshOverlay() {
        if (!Prefs.overlay(this)) {
            removeOverlay(); return
        }
        if (overlay == null) createOverlay()
        val on = Prefs.active(this)
        overlay?.apply {
            text = ""
            (background as? GradientDrawable)?.setColor(if (on) Color.rgb(46, 160, 67) else Color.rgb(200, 50, 50))
        }
        updateVis()
    }

    private fun createOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (56 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { params.x = sx + dx; params.y = sy + dy; wm.updateViewLayout(v, params) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) Prefs.setActive(this@AutoService, !Prefs.active(this@AutoService))
                }
                return true
            }
        })
        try {
            wm.addView(tv, params)
            overlay = tv
        } catch (_: Exception) {
        }
    }

    private fun removeOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }
}
