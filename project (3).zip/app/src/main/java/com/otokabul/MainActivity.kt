package com.otokabul

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private var showLic = false
    private var keyText = ""
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int = 14, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun tv(t: String, size: Float = 14f, color: String = "#111827", bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor(color))
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, 16)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(12) }
    }

    private fun LinearLayout.put(v: View, top: Int = 8, h: Int = W) {
        addView(v, LinearLayout.LayoutParams(M, h).apply { topMargin = dp(top) })
    }

    private fun btn(t: String, color: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = shape(Color.parseColor(color), 12)
        setOnClickListener { onClick() }
    }

    private fun field(value: String, numeric: Boolean, onChange: (String) -> Unit) = EditText(this).apply {
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
        setText(value)
        setSingleLine()
        textSize = 18f
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = shape(Color.parseColor("#F9FAFB"), 10, Color.parseColor("#6B7280"))
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { onChange(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun copy(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kod", t))
        Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
    }

    private fun legText(m: Int, d: String) = if (m < 0) "-" else "$m dk · $d"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#F2F4F8")); addView(box) })
    }

    override fun onResume() {
        super.onResume()
        License.sync(this)
        render()
    }

    private fun licenseCard(ok: Boolean) {
        val c = card()
        c.addView(tv(if (ok) "Lisansı yenile" else "Lisans gerekli", 18f, "#111827", true))
        c.put(tv("Cihaz kodun (yöneticiye gönder):", 13f, "#6B7280"), 8)
        c.put(tv(License.deviceId(this), 22f, "#1E3A8A", true), 4)
        c.put(btn("Kodu kopyala", "#6B7280") { copy(License.deviceId(this)) }, 6, dp(44))
        c.put(tv("Lisans anahtarı:", 13f, "#6B7280"), 12)
        c.put(field("", false) { keyText = it }, 4)
        c.put(btn("Etkinleştir", "#1E3A8A") {
            val err = License.activate(this, keyText)
            if (err == null) {
                showLic = false
                Toast.makeText(this, "Lisans etkinleştirildi", Toast.LENGTH_LONG).show()
                render()
            } else Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        }, 8, dp(48))
        c.put(tv("Paketler: Günlük · Haftalık · Aylık · 6 Aylık", 13f, "#6B7280"), 10)
        box.addView(c)
    }

    private fun render() {
        box.removeAllViews()
        val rem = License.remainingMs(this)
        val ok = rem > 0L
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Gezen Tavuk", 26f, "#1E3A8A", true), LinearLayout.LayoutParams(0, W, 1f))
        val left = if (rem >= 86400000L) "${rem / 86400000L} gün kaldı" else "${rem / 3600000L} saat kaldı"
        head.addView(tv(if (ok) left else "Lisans yok", 13f, "#FFFFFF", true).apply {
            background = shape(Color.parseColor(if (ok) "#16A34A" else "#DC2626"), 20)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        })
        box.addView(head)
        if (!ok || showLic) {
            licenseCard(ok)
            if (!ok) return
        }

        val on = Prefs.active(this)
        val big = TextView(this).apply {
            text = if (on) "OTOMATİK KABUL: AÇIK" else "OTOMATİK KABUL: KAPALI"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = shape(Color.parseColor(if (on) "#16A34A" else "#DC2626"), 24)
            setOnClickListener { Prefs.setActive(this@MainActivity, !Prefs.active(this@MainActivity)); render() }
        }
        box.put(big, 16, dp(110))

        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val sc = card()
        sc.addView(tv(if (en) "Erişilebilirlik: AÇIK ✅" else "Erişilebilirlik: KAPALI ❌", 16f, "#111827", true))
        sc.put(btn("Erişilebilirlik ayarlarını aç", "#1E3A8A") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, 8, dp(46))
        box.addView(sc)

        val fc = card()
        fc.addView(tv("Filtreler", 18f, "#111827", true))
        fc.put(tv("En az tutar (₺, soldaki rakam)", 13f, "#6B7280"), 10)
        fc.put(field(Prefs.minPrice(this).toString(), true) { Prefs.setMinPrice(this, it.toIntOrNull() ?: 0) }, 4)
        fc.put(tv("Kabul öncesi bekleme (ms)", 13f, "#6B7280"), 10)
        fc.put(field(Prefs.delay(this).toString(), true) { Prefs.setDelay(this, it.toLongOrNull() ?: 0L) }, 4)
        fc.put(Switch(this).apply {
            text = "Ekranda ON/OFF butonu"
            isChecked = Prefs.overlay(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setOverlay(this@MainActivity, v) }
        }, 14)
        box.addView(fc)

        val jobs = Prefs.jobs(this)
        val lc = card()
        lc.addView(tv("Son kabul edilen iş", 18f, "#111827", true))
        val last = jobs.lastOrNull()
        if (last == null) lc.put(tv("Henüz iş alınmadı", 14f, "#6B7280"), 6)
        else {
            lc.put(tv("₺${last.price}", 28f, "#16A34A", true), 4)
            lc.put(tv("Yolculuk: ${legText(last.tMin, last.tDist)}", 17f, "#111827", true), 2)
            lc.put(tv("Yolcuya: ${legText(last.pMin, last.pDist)}", 14f, "#4B5563"), 2)
        }
        box.addView(lc)

        val hc = card()
        hc.addView(tv("${Prefs.count(this)} iş alındı · toplam ₺${Prefs.sum(this)}", 18f, "#111827", true))
        hc.put(tv("Son 10 iş (en yeni üstte)", 13f, "#6B7280"), 2)
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        jobs.reversed().forEach { j ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(Color.parseColor("#F3F4F6"), 10)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            row.addView(tv("${f.format(Date(j.ts))}   ₺${j.price}", 15f, "#111827", true))
            row.addView(tv("Yolculuk ${legText(j.tMin, j.tDist)}  ·  Yolcuya ${legText(j.pMin, j.pDist)}", 13f, "#4B5563"))
            hc.put(row, 8)
        }
        hc.put(btn("Kayıtları sıfırla", "#6B7280") { Prefs.clearJobs(this); render() }, 12, dp(44))
        box.addView(hc)

        val lic = card()
        val endF = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        lic.addView(tv("Lisans bitişi: ${endF.format(Date(System.currentTimeMillis() + rem))}", 14f, "#111827", true))
        lic.put(btn("Yeni lisans anahtarı gir", "#1E3A8A") { showLic = true; render() }, 8, dp(44))
        box.addView(lic)
    }
}
