plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.otokabul"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gezentavuk"
        minSdk = 24
        targetSdk = 34
        versionCode = 16
        versionName = "3.0"
    }
    signingConfigs {
        create("fixed") {
            storeFile = rootProject.file("release.p12")
            storePassword = "gezentavuk"
            keyAlias = "gt"
            keyPassword = "gezentavuk"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
