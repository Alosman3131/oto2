package com.otokabul

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private var showLic = false
    private var keyText = ""
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int = 14, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun tv(t: String, size: Float = 14f, color: String = "#111827", bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor(color))
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, 16)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(12) }
    }

    private fun LinearLayout.put(v: View, top: Int = 8, h: Int = W) {
        addView(v, LinearLayout.LayoutParams(M, h).apply { topMargin = dp(top) })
    }

    private fun btn(t: String, color: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = shape(Color.parseColor(color), 12)
        setOnClickListener { onClick() }
    }

    private fun toggle(label: String, on: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = "$label: ${if (on) "AÇIK" else "KAPALI"}"
        textSize = 18f
        setTypeface(null, Typeface.BOLD)
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = shape(Color.parseColor(if (on) "#16A34A" else "#DC2626"), 20)
        setOnClickListener { onClick() }
    }

    private fun line(label: String, ok: Boolean) =
        tv((if (ok) "✅ " else "❌ ") + label, 14f, if (ok) "#166534" else "#B91C1C")

    private fun field(value: String, numeric: Boolean, onChange: (String) -> Unit) = EditText(this).apply {
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
        setText(value)
        setSingleLine()
        textSize = 18f
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = shape(Color.parseColor("#F9FAFB"), 10, Color.parseColor("#6B7280"))
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { onChange(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun copy(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kod", t))
        Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
    }

    private fun legText(m: Int, d: String) = if (m < 0) "-" else "$m dk · $d"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#F2F4F8")); addView(box) })
    }

    override fun onResume() {
        super.onResume()
        License.sync(this)
        render()
    }

    private fun licenseCard(ok: Boolean) {
        val c = card()
        c.addView(tv(if (ok) "Lisansı yenile" else "Lisans gerekli", 18f, "#111827", true))
        c.put(tv("Cihaz kodun (yöneticiye gönder):", 13f, "#6B7280"), 8)
        c.put(tv(License.deviceId(this), 22f, "#1E3A8A", true), 4)
        c.put(btn("Kodu kopyala", "#6B7280") { copy(License.deviceId(this)) }, 6, dp(44))
        c.put(tv("Lisans anahtarı:", 13f, "#6B7280"), 12)
        c.put(field("", false) { keyText = it }, 4)
        c.put(btn("Etkinleştir", "#1E3A8A") {
            val err = License.activate(this, keyText)
            if (err == null) {
                showLic = false
                Toast.makeText(this, "Lisans etkinleştirildi", Toast.LENGTH_LONG).show()
                render()
            } else Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        }, 8, dp(48))
        c.put(tv("Paketler: Günlük · Haftalık · Aylık · 6 Aylık", 13f, "#6B7280"), 10)
        box.addView(c)
    }

    private fun render() {
        box.removeAllViews()
        val rem = License.remainingMs(this)
        val ok = rem > 0L
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Gezen Tavuk", 26f, "#1E3A8A", true), LinearLayout.LayoutParams(0, W, 1f))
        val left = if (rem >= 86400000L) "${rem / 86400000L} gün kaldı" else "${rem / 3600000L} saat kaldı"
        head.addView(tv(if (ok) left else "Lisans yok", 13f, "#FFFFFF", true).apply {
            background = shape(Color.parseColor(if (ok) "#16A34A" else "#DC2626"), 20)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        })
        box.addView(head)
        if (!ok || showLic) {
            licenseCard(ok)
            if (!ok) return
        }

        // 1) Normal işler
        val nc = card()
        nc.addView(tv("Otomatik kabul (normal işler)", 18f, "#111827", true))
        nc.put(toggle("OTOMATİK KABUL", Prefs.active(this)) {
            Prefs.setActive(this, !Prefs.active(this)); render()
        }, 10, dp(84))
        nc.put(tv("En az tutar (₺, soldaki rakam)", 13f, "#6B7280"), 12)
        nc.put(field(Prefs.minPrice(this).toString(), true) { Prefs.setMinPrice(this, it.toIntOrNull() ?: 0) }, 4)
        nc.put(tv("Kabul öncesi bekleme (ms)", 13f, "#6B7280"), 10)
        nc.put(field(Prefs.delay(this).toString(), true) { Prefs.setDelay(this, it.toLongOrNull() ?: 0L) }, 4)
        box.addView(nc)

        // 2) Rezervasyon (normal işlerden bağımsız anahtar ve filtreler)
        val rc = card()
        rc.addView(tv("Rezervasyon", 18f, "#111827", true))
        rc.put(toggle("REZERVASYON", Prefs.resActive(this)) {
            Prefs.setResActive(this, !Prefs.resActive(this)); render()
        }, 10, dp(70))
        rc.put(tv("En az tutar (₺)", 13f, "#6B7280"), 12)
        rc.put(field(Prefs.resMin(this).toString(), true) { Prefs.setResMin(this, it.toIntOrNull() ?: 0) }, 4)
        rc.put(tv("En erken alış saati, sadece bugünkü rezervasyonlarda (örn. 04:00, boş = sınır yok)", 13f, "#6B7280"), 10)
        rc.put(field(Prefs.resEarliest(this), false) { Prefs.setResEarliest(this, it) }, 4)
        rc.put(tv("Yarın ve sonraki günlerin rezervasyonlarında saat sınırı uygulanmaz. Rezervasyon talepleri sayfası açık kalırsa orayı da izler, kabul sonrası çıkan Evet onayına basar.", 12f, "#6B7280"), 8)
        box.addView(rc)

        // 3) Radar
        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val batOk = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val netOk = cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val rd = card()
        rd.addView(tv("Radar", 18f, "#111827", true))
        rd.put(line("Erişilebilirlik hizmeti açık", en), 8)
        rd.put(line("Pil kısıtlaması kaldırıldı", batOk), 4)
        rd.put(line("İnternet var", netOk), 4)
        rd.put(toggle("RADAR", Prefs.radar(this)) { Prefs.setRadar(this, !Prefs.radar(this)); render() }, 12, dp(70))
        rd.put(tv("Radar açıkken telefon uykuya dalmaz, uygulama arka planda kapanmaz. Pili biraz daha tüketir, araçta şarjdayken kullan.", 12f, "#6B7280"), 8)
        rd.put(btn("Erişilebilirlik ayarlarını aç", "#1E3A8A") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, 10, dp(46))
        if (!batOk) rd.put(btn("Pil kısıtlamasını kaldır", "#1E3A8A") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }, 6, dp(46))
        rd.put(btn("Uygulama ayarları (otomatik başlat)", "#6B7280") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, 6, dp(46))
        val tp = Prefs.taxiPkg(this)
        rd.put(tv(if (tp.isEmpty()) "Taksi uygulaması ilk kabulde otomatik öğrenilir" else "Takip edilen uygulama: $tp", 12f, "#6B7280"), 8)
        if (tp.isNotEmpty()) rd.put(btn("Takibi sıfırla", "#6B7280") { Prefs.clearTaxiPkg(this); render() }, 6, dp(40))
        box.addView(rd)

        val jobs = Prefs.jobs(this)
        val lc = card()
        lc.addView(tv("Son kabul edilen iş", 18f, "#111827", true))
        val last = jobs.lastOrNull()
        if (last == null) lc.put(tv("Henüz iş alınmadı", 14f, "#6B7280"), 6)
        else {
            lc.put(tv("₺${last.price}", 28f, "#16A34A", true), 4)
            if (last.res) lc.put(tv("Rezervasyon", 13f, "#B45309", true), 2)
            lc.put(tv("Yolculuk: ${legText(last.tMin, last.tDist)}", 17f, "#111827", true), 2)
            lc.put(tv("Yolcuya: ${legText(last.pMin, last.pDist)}", 14f, "#4B5563"), 2)
        }
        box.addView(lc)

        val hc = card()
        hc.addView(tv("${Prefs.count(this)} iş alındı · toplam ₺${Prefs.sum(this)}", 18f, "#111827", true))
        hc.put(tv("Son 10 iş (en yeni üstte)", 13f, "#6B7280"), 2)
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        jobs.reversed().forEach { j ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(Color.parseColor("#F3F4F6"), 10)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            row.addView(tv("${f.format(Date(j.ts))}   ₺${j.price}${if (j.res) "   (Rezervasyon)" else ""}", 15f, "#111827", true))
            row.addView(tv("Yolculuk ${legText(j.tMin, j.tDist)}  ·  Yolcuya ${legText(j.pMin, j.pDist)}", 13f, "#4B5563"))
            hc.put(row, 8)
        }
        hc.put(btn("Kayıtları sıfırla", "#6B7280") { Prefs.clearJobs(this); render() }, 12, dp(44))
        box.addView(hc)

        val lic = card()
        val endF = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        lic.addView(tv("Lisans bitişi: ${endF.format(Date(System.currentTimeMillis() + rem))}", 14f, "#111827", true))
        lic.put(btn("Yeni lisans anahtarı gir", "#1E3A8A") { showLic = true; render() }, 8, dp(44))
        box.addView(lic)
    }
}
