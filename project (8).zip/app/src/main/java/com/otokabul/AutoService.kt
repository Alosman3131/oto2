package com.otokabul

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.Calendar
import kotlin.math.abs

class AutoService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var pending = false
    private var lastClick = 0L
    private var lastScan = 0L
    private var overlay: TextView? = null
    private var chip: TextView? = null
    private var onHome = false
    private var homePkgs: Set<String> = setOf("com.miui.home")
    private val priceRe = Regex("₺\\s*(\\d{1,3}(?:[.,]\\d{3})+|\\d+)")
    private val rangeRe = Regex("₺\\s*(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*[-–—]\\s*\\d")
    private val priceRe2 = Regex("(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*₺")
    private val legRe = Regex("(?:(\\d+)\\s*sa\\s*)?(\\d+)\\s*dk[^\\d]{0,5}([\\d.,]+)\\s*(km|m)\\b")
    private var lastOffer = -1
    private val timeRe = Regex("(?<![\\d:])([01]?\\d|2[0-3]):([0-5]\\d)(?![\\d:])")
    private val dateRe = Regex("(\\d{1,2})\\s+(ocak|şubat|mart|nisan|mayıs|haziran|temmuz|ağustos|eylül|ekim|kasım|aralık)")
    private val months = listOf("ocak", "şubat", "mart", "nisan", "mayıs", "haziran", "temmuz", "ağustos", "eylül", "ekim", "kasım", "aralık")
    private var wl: PowerManager.WakeLock? = null

    // 1 = bugün, 2 = yarın, 3 = daha sonraki gün
    private fun dayKindOf(day: Int, mon: Int): Int {
        val c = Calendar.getInstance()
        if (day == c.get(Calendar.DAY_OF_MONTH) && mon == c.get(Calendar.MONTH)) return 1
        c.add(Calendar.DAY_OF_MONTH, 1)
        if (day == c.get(Calendar.DAY_OF_MONTH) && mon == c.get(Calendar.MONTH)) return 2
        return 3
    }
    private var lastDiag = ""
    private val hideChip = Runnable { removeChip() }
    private val syncLoop = object : Runnable {
        override fun run() {
            License.sync(this@AutoService)
            handler.postDelayed(this, 1800000L)
        }
    }

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post { refreshOverlay() }
    }

    private class State {
        var btn: AccessibilityNodeInfo? = null
        var res = false
        var hasTitle = false
        var hasAll = false
        var kabulCount = 0
        var minutes = -1
        var dayKind = 0
        val prices = ArrayList<Int>()
        val singles = ArrayList<Int>()
        val legs = ArrayList<Leg>()
        val texts = ArrayList<String>()
    }

    private class Offer(val price: Int, val btn: AccessibilityNodeInfo, val pick: Leg?, val trip: Leg?, val res: Boolean, val dayKind: Int, val minutes: Int)

    override fun onServiceConnected() {
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homePkgs = packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet() + "com.miui.home"
        } catch (_: Exception) {
        }
        onHome = homePkgs.contains(rootInActiveWindow?.packageName?.toString() ?: "")
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        refreshOverlay()
        handler.post(syncLoop)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(syncLoop)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        removeOverlay()
        removeChip()
        wl?.let { if (it.isHeld) it.release() }
        wl = null
        super.onDestroy()
    }

    private val skipPkgs = setOf(
        "com.google.android.apps.maps", "com.waze", "com.yandex.yandexnavi", "ru.yandex.yandexmaps",
        "com.google.android.inputmethod.latin", "com.samsung.android.honeyboard", "com.touchtype.swiftkey"
    )
    private var candPkg = ""

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        if ((!Prefs.active(this) && !Prefs.resActive(this)) || pending || !License.valid(this)) return
        val pkg = e.packageName?.toString() ?: return
        // Kendi ekranımızı, sistemi, haritayı ve klavyeyi okumayız, telefonu yormasın
        if (pkg == packageName || pkg == "com.android.systemui" || skipPkgs.contains(pkg)) return
        val taxi = Prefs.taxiPkg(this)
        if (taxi.isNotEmpty() && pkg != taxi) return
        val now = SystemClock.uptimeMillis()
        if (now - lastClick < 4000 || now - lastScan < 40) return
        lastScan = now
        var root: AccessibilityNodeInfo = e.source ?: return
        while (true) {
            root = root.parent ?: break
        }
        val o = scanRoots(listOf(root))
        val took = SystemClock.uptimeMillis() - now
        if (o == null) {
            lastOffer = -1
            return
        }
        candPkg = pkg
        val okPrice = passes(o)
        if (!okPrice) return
        val d = Prefs.delay(this)
        if (d <= 0L) {
            accept(o)
            return
        }
        pending = true
        handler.postDelayed({
            try {
                run {
                    val o2 = scan()
                    if (o2 != null && passes(o2)) accept(o2)
                }
            } finally {
                pending = false
            }
        }, maxOf(0L, d - took))
    }

    // Normal işler ve rezervasyonlar ayrı anahtar ve ayrı filtrelerle değerlendirilir
    private fun passes(o: Offer): Boolean {
        if (o.res) {
            if (!Prefs.resActive(this)) return false
            if (o.price < Prefs.resMin(this)) return false
            val early = Prefs.resEarliestMin(this)
            if (early >= 0) {
                // En erken alış saati sadece bugünkü işlerde uygulanır, yarın ve sonrası saate bakılmaz
                if (o.dayKind == 1) {
                    if (o.minutes < 0 || o.minutes < early) return false
                } else if (o.dayKind == 0) {
                    return false // tarih okunamadı, güvenli tarafta kal
                }
            }
            return true
        }
        return Prefs.active(this) && o.price >= Prefs.minPrice(this)
    }

    private fun accept(o: Offer) {
        click(o.btn)
        if (candPkg.isNotEmpty()) Prefs.setTaxiPkg(this, candPkg)
        Prefs.addJob(this, o.price, o.pick, o.trip, o.res)
        lastClick = SystemClock.uptimeMillis()
        startConfirm()
    }

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val roots = ArrayList<AccessibilityNodeInfo>()
        try {
            windows.forEach { w -> w.root?.let { roots.add(it) } }
        } catch (_: Exception) {
        }
        rootInActiveWindow?.let { roots.add(it) }
        return roots
    }

    private fun scan(): Offer? = scanRoots(allRoots())

    // Kabul ettikten sonra çıkan "Evet" onayını bulup basar (rezervasyonlarda onay isteniyor)
    private var confirmUntil = 0L
    private val confirmLoop = object : Runnable {
        override fun run() {
            if (SystemClock.uptimeMillis() > confirmUntil) return
            for (root in allRoots()) {
                val y = findYes(root)
                if (y != null) {
                    pressYes(y)
                    confirmUntil = 0L
                    return
                }
            }
            handler.postDelayed(this, 100)
        }
    }

    private fun startConfirm() {
        confirmUntil = SystemClock.uptimeMillis() + 5000
        handler.removeCallbacks(confirmLoop)
        handler.postDelayed(confirmLoop, 120)
    }

    private fun findYes(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (t != null && t.equals("evet", true)) return n
        for (i in 0 until n.childCount) {
            val r = findYes(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun pressYes(n: AccessibilityNodeInfo) {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0) tap(r.centerX(), r.centerY())
        handler.postDelayed({
            for (root in allRoots()) {
                val y = findYes(root) ?: continue
                var c: AccessibilityNodeInfo? = y
                while (c != null && !c.isClickable) c = c.parent
                c?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                break
            }
        }, 250)
    }

    private fun scanRoots(roots: List<AccessibilityNodeInfo>): Offer? {
        for (r in roots) {
            val s = State()
            walk(r, s)
            // Üstü çizili eski fiyat ile indirimli fiyat birlikte varsa düşük olan (gerçek kazanç) alınır
            val p = s.prices.filter { it >= 30 }.minOrNull() ?: s.singles.firstOrNull { it >= 30 }
            val page = s.hasTitle && s.hasAll
            if (page && s.kabulCount != 1) continue // listede birden fazla kart varsa karıştırmamak için atlanır
            if (s.btn != null && p != null) {
                val pick = if (s.legs.size >= 2) s.legs[0] else null
                val trip = if (s.legs.size >= 2) s.legs[1] else s.legs.firstOrNull()
                return Offer(p, s.btn!!, pick, trip, s.res || page, s.dayKind, s.minutes)
            }
        }
        return null
    }

    private fun walk(n: AccessibilityNodeInfo?, s: State) {
        if (n == null) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty()) {
            val low = t.lowercase()
            if (low.contains("rezervasyon") && low != "rezervasyonlarım" && low != "rezervasyon talepleri" && !low.startsWith("herhangi bir")) s.res = true
            if (low == "rezervasyon talepleri") s.hasTitle = true
            if (low == "tümü") s.hasAll = true
            if (low == "kabul et") s.kabulCount++
            if (s.btn == null && t.contains("kabul et", true) && !t.contains("kabul etme", true)) s.btn = n
            // Rezervasyon tarih ve saati: aynı yazıda gün bilgisi (bugün, yarın, 27 kasım) ve saat birlikte olmalı
            if (s.minutes < 0) {
                val tm = timeRe.find(low)
                if (tm != null) {
                    var dk = 0
                    if (low.contains("bugün")) dk = 1 else if (low.contains("yarın")) dk = 2
                    val dm = dateRe.find(low)
                    if (dm != null) dk = dayKindOf(dm.groupValues[1].toInt(), months.indexOf(dm.groupValues[2]))
                    if (dk != 0) {
                        s.minutes = tm.groupValues[1].toInt() * 60 + tm.groupValues[2].toInt()
                        s.dayKind = dk
                    }
                }
            }
            val skip = low.contains("bonus") || low.contains("bahşiş") || low.contains("ek kazanç") || t.startsWith("+")
            if (!skip) {
                // Asıl fiyat "₺885 - 1.095" gibi aralık biçimindedir, tek ₺ tutarları (bonus, bahşiş) yedek olarak kalır
                val rm = rangeRe.find(t)
                if (rm != null) {
                    val v = rm.groupValues[1].replace(".", "").replace(",", "").toIntOrNull() ?: 0
                    if (v > 0) s.prices.add(v)
                } else {
                    val m = priceRe.find(t) ?: priceRe2.find(t)
                    if (m != null) {
                        val v = m.groupValues[1].replace(".", "").replace(",", "").toIntOrNull() ?: 0
                        if (v > 0) s.singles.add(v)
                    }
                }
            }
            legRe.findAll(t).forEach {
                val h = it.groupValues[1].toIntOrNull() ?: 0
                s.legs.add(Leg(h * 60 + it.groupValues[2].toInt(), it.groupValues[3] + " " + it.groupValues[4]))
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), s)
    }

    private fun tap(x: Int, y: Int) {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null
        )
    }

    // Önce gerçek dokunuş (parmak gibi), teklif hâlâ ekrandaysa klasik tıklama da denenir
    private fun click(btn: AccessibilityNodeInfo) {
        val r = Rect()
        btn.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0) tap(r.centerX(), r.centerY())
        handler.postDelayed({
            val o = scan()
            if (o != null) {
                var n: AccessibilityNodeInfo? = o.btn
                while (n != null && !n.isClickable) n = n.parent
                n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }, 250)
    }

    private fun updateVis() {
        val v = if (onHome) View.GONE else View.VISIBLE
        overlay?.visibility = v
        chip?.visibility = v
    }

    private fun showChip(o: Offer) {
        val t = o.trip ?: return
        var s = "Yolculuk: ${t.min} dk · ${t.dist}"
        o.pick?.let { s += "\nYolcuya: ${it.min} dk · ${it.dist}" }
        handler.removeCallbacks(hideChip)
        removeChip()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pad = (12 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = s
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            background = GradientDrawable().apply { setColor(Color.argb(230, 17, 24, 39)); cornerRadius = 40f }
            visibility = if (onHome) View.GONE else View.VISIBLE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 120 }
        try {
            wm.addView(tv, lp)
            chip = tv
            handler.postDelayed(hideChip, 3000L)
        } catch (_: Exception) {
        }
    }

    private fun removeChip() {
        chip?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        chip = null
    }

    // Yüzen buton ve bilgi kutusu yok. Radar açıksa işlemci uyanık tutulur
    private fun refreshOverlay() {
        removeOverlay()
        removeChip()
        if (Prefs.radar(this)) {
            if (wl == null) {
                wl = (getSystemService(POWER_SERVICE) as PowerManager)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gezentavuk:radar")
                    .apply { setReferenceCounted(false); acquire() }
            }
        } else {
            wl?.let { if (it.isHeld) it.release() }
            wl = null
        }
    }

    private fun createOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (56 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { params.x = sx + dx; params.y = sy + dy; wm.updateViewLayout(v, params) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) Prefs.setActive(this@AutoService, !Prefs.active(this@AutoService))
                }
                return true
            }
        })
        try {
            wm.addView(tv, params)
            overlay = tv
        } catch (_: Exception) {
        }
    }

    private fun removeOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }
}
