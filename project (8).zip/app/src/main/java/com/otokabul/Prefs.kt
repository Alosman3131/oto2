package com.otokabul

import android.content.Context
import android.content.SharedPreferences

class Leg(val min: Int, val dist: String)
class Job(val ts: Long, val price: Int, val pMin: Int, val pDist: String, val tMin: Int, val tDist: String, val res: Boolean = false)

object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun minPrice(c: Context) = sp(c).getInt("min", 250)
    fun setMinPrice(c: Context, v: Int) = sp(c).edit().putInt("min", v).apply()
    fun delay(c: Context) = sp(c).getLong("delay", 240L)
    fun setDelay(c: Context, v: Long) = sp(c).edit().putLong("delay", v).apply()
    fun active(c: Context) = sp(c).getBoolean("active", false)
    fun setActive(c: Context, v: Boolean) = sp(c).edit().putBoolean("active", v).apply()
    fun overlay(c: Context) = sp(c).getBoolean("overlay", false)
    fun setOverlay(c: Context, v: Boolean) = sp(c).edit().putBoolean("overlay", v).apply()
    fun resOn(c: Context) = sp(c).getBoolean("reson", true)
    fun setResOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("reson", v).apply()
    fun resMin(c: Context) = sp(c).getInt("resmin", 500)
    fun setResMin(c: Context, v: Int) = sp(c).edit().putInt("resmin", v).apply()
    fun resActive(c: Context) = sp(c).getBoolean("resactive", true)
    fun setResActive(c: Context, v: Boolean) = sp(c).edit().putBoolean("resactive", v).apply()
    fun radar(c: Context) = sp(c).getBoolean("radar", false)
    fun setRadar(c: Context, v: Boolean) = sp(c).edit().putBoolean("radar", v).apply()
    fun resEarliest(c: Context) = sp(c).getString("researly", "") ?: ""
    fun setResEarliest(c: Context, v: String) = sp(c).edit().putString("researly", v).apply()
    // En erken alış saati dakika olarak, boşsa -1 (sınır yok)
    fun resEarliestMin(c: Context): Int {
        val t = resEarliest(c).trim()
        if (t.isEmpty()) return -1
        val p = t.split(":")
        val h = p[0].toIntOrNull() ?: return -1
        val m = p.getOrNull(1)?.toIntOrNull() ?: 0
        return if (h in 0..23 && m in 0..59) h * 60 + m else -1
    }
    fun key(c: Context) = sp(c).getString("key", "") ?: ""
    fun count(c: Context) = sp(c).getInt("count", 0)
    fun sum(c: Context) = sp(c).getInt("sum", 0)

    private fun lines(c: Context) = (sp(c).getString("jobs", "") ?: "").split(";").filter { it.contains("|") }

    fun jobs(c: Context): List<Job> = lines(c).mapNotNull {
        val a = it.split("|")
        if (a.size < 6) null else Job(a[0].toLong(), a[1].toInt(), a[2].toInt(), a[3], a[4].toInt(), a[5], a.getOrNull(6) == "true")
    }

    // Listede en fazla 10 kayıt tutulur, 11. gelince en eski silinir
    fun addJob(c: Context, price: Int, p: Leg?, t: Leg?, res: Boolean) {
        val line = "${System.currentTimeMillis()}|$price|${p?.min ?: -1}|${p?.dist ?: ""}|${t?.min ?: -1}|${t?.dist ?: ""}|$res"
        val list = (lines(c) + line).takeLast(10)
        sp(c).edit().putString("jobs", list.joinToString(";") + ";")
            .putInt("count", count(c) + 1).putInt("sum", sum(c) + price).apply()
    }

    fun setSeen(c: Context, price: Int, ok: Boolean) =
        sp(c).edit().putString("offer", "${System.currentTimeMillis()}|$price|$ok").apply()

    fun seen(c: Context): Triple<Long, Int, Boolean>? {
        val a = (sp(c).getString("offer", "") ?: "").split("|")
        return if (a.size < 3) null else Triple(a[0].toLong(), a[1].toInt(), a[2] == "true")
    }

    fun setDiag(c: Context, t: String) = sp(c).edit().putString("diag", t).apply()
    fun diag(c: Context) = sp(c).getString("diag", "") ?: ""
    fun clearDiag(c: Context) = sp(c).edit().putString("diag", "").apply()

    fun taxiPkg(c: Context) = sp(c).getString("taxipkg", "") ?: ""
    fun setTaxiPkg(c: Context, v: String) {
        if (taxiPkg(c) != v) sp(c).edit().putString("taxipkg", v).apply()
    }
    fun clearTaxiPkg(c: Context) = sp(c).edit().putString("taxipkg", "").apply()

    fun clearJobs(c: Context) = sp(c).edit().putString("jobs", "").putInt("count", 0).putInt("sum", 0).apply()
}
