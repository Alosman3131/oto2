package com.otokabul

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

object License {
    private const val PUB = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEnMcawjxrWCVfH6l0YKsIXPvoiVlMUknVJxo3sCZYPfHZkj6LzJWy0Pgwf7Cr15L/P4cWPmCNc3A7dNFUWZJl6Q=="
    class Info(val days: Int, val issued: Long)
    private var cAt = 0L
    private var cOk = false

    fun deviceId(c: Context): String {
        val id = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "x"
        val h = MessageDigest.getInstance("SHA-256").digest(("ok1" + id).toByteArray())
            .joinToString("") { "%02X".format(it) }
        return h.substring(0, 5) + "-" + h.substring(5, 10)
    }

    private fun u(s: String) = Base64.decode(s, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)

    private fun der(raw: ByteArray): ByteArray {
        fun i(b: ByteArray): ByteArray {
            var x = b.dropWhile { it == 0.toByte() }.toByteArray()
            if (x.isEmpty()) x = byteArrayOf(0)
            if (x[0] < 0) x = byteArrayOf(0) + x
            return byteArrayOf(2, x.size.toByte()) + x
        }
        val a = i(raw.copyOfRange(0, 32))
        val b = i(raw.copyOfRange(32, 64))
        return byteArrayOf(0x30, (a.size + b.size).toByte()) + a + b
    }

    fun verify(c: Context, key: String): Info? {
        try {
            val parts = key.filter { !it.isWhitespace() }.split(".")
            if (parts.size != 2) return null
            val payload = u(parts[0])
            val sig = u(parts[1])
            if (sig.size != 64) return null
            val pk = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(PUB, Base64.DEFAULT)))
            val s = Signature.getInstance("SHA256withECDSA")
            s.initVerify(pk)
            s.update(payload)
            if (!s.verify(der(sig))) return null
            val f = String(payload).split("|")
            if (f.size != 4 || f[0] != "OK1" || f[1] != deviceId(c)) return null
            return Info(f[2].toInt(), f[3].toLong())
        } catch (e: Exception) {
            return null
        }
    }

    // Telefon saati geri alınırsa son görülen en büyük zaman kullanılır
    private fun trustedNow(c: Context): Long {
        val sp = Prefs.sp(c)
        val last = sp.getLong("seen", 0L)
        val now = System.currentTimeMillis()
        if (now > last) sp.edit().putLong("seen", now).apply()
        return maxOf(now, last)
    }

    fun remainingMs(c: Context): Long {
        val i = verify(c, Prefs.key(c)) ?: return 0L
        return maxOf(0L, i.issued + i.days * 86400000L - trustedNow(c))
    }

    fun valid(c: Context): Boolean {
        val n = SystemClock.elapsedRealtime()
        if (n - cAt > 30000L) {
            cOk = remainingMs(c) > 0L
            cAt = n
        }
        return cOk
    }

    fun activate(c: Context, key: String): String? {
        val i = verify(c, key) ?: return "Anahtar geçersiz veya bu cihaz için üretilmemiş"
        if (i.issued + i.days * 86400000L <= trustedNow(c)) return "Bu anahtarın süresi dolmuş"
        Prefs.sp(c).edit().putString("key", key.filter { !it.isWhitespace() }).apply()
        cAt = 0L
        return null
    }

    // İnternetten gerçek saati alır, saat oyunlarına karşı koruma
    fun sync(c: Context) {
        Thread {
            try {
                val cn = URL("https://www.google.com").openConnection() as HttpURLConnection
                cn.requestMethod = "HEAD"
                cn.connectTimeout = 5000
                cn.readTimeout = 5000
                val d = cn.date
                cn.disconnect()
                if (d > 0L) Prefs.sp(c).edit().putLong("seen", d).apply()
            } catch (_: Exception) {
            }
        }.start()
    }
}
